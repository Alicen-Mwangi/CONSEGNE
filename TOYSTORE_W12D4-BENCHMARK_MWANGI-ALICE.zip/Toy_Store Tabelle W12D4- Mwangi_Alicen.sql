CREATE TABLE Product (
    Product_Id INT NOT NULL PRIMARY KEY,
    Product_Name VARCHAR(255),
    Category VARCHAR(255),
    Price DOUBLE
);
SELECT 
    *
FROM
    Product;
-- DROP TABLE Product;
INSERT INTO Product (Product_Id,Product_Name,Category,Price) VALUES
(201,"Barbie Dreamhouse","Creative",159.99),
(202,"Furby Interactive Plush Toy","Educational",20.50),
(203,"Cookeez Makery","Creative",50.50),
(204,"Clue Squishmallows Edition","Adventure",69.99),
(205,"Robo Rally","Adventure",59.90),
(206,"LEGO Creator Space Roller Coaster","Adventure",99.99),
(207,"Swagtron Zipboard","Adventure",399.99),
(208,"Magic Adventures Microscope","Educational",79.99),
(209,"Gabby’s Dollhouse Cook with Cakey Kitchen Set","Creative",115.99),
(210,"Pixobitz Studio Set","Creative",24.99);

CREATE TABLE Region (
    Region_Id INT NOT NULL PRIMARY KEY,
    Region_Name VARCHAR(100)
);
INSERT INTO Region (Region_Id,Region_Name)
VALUES 
(1,"Abruzzo"),
(2,"Basilicata"),
(3,"Calabria"),
(4,"Campania"),
(5,"Emilia-Romagna"),
(6,"Friuli-Venezia Giulia"),
(7,"Lazio"),
(8,"Lombardy"),
(9,"Marche"),
(10,"Molise"),
(11,"Piedmont"),
(12,"Liguria"),
(13,"Puglia"),
(14,"Sardinia"),
(15,"Sicily"),
(16,"Trentino Alto Adige"),
(17,"Tuscany"),
(18,"Umbria"),
(19,"Valle d'Aosta"),
(20,"Veneto");

-- SELECT * FROM Region;

CREATE TABLE Sales (
    Sales_Id INT NOT NULL PRIMARY KEY,
    Transaction_date DATE,
    Quantity_Sold INT,
    Region_Id INT,
    Product_Id INT,
    FOREIGN KEY (Region_Id)
        REFERENCES Region (Region_Id),
    FOREIGN KEY (Product_Id)
        REFERENCES Product (Product_Id)
);

INSERT INTO Sales (Sales_Id,Transaction_date,Quantity_Sold,Region_Id,Product_Id)
 VALUES
 -- (1001,"2023-01-20",25,5,205);
 (1002,"2023-01-22",43,1,201),
 (1003,"2023-01-20",5,2,202),
 (1000,"2023-01-01",250,3,203),
 (1004,"2023-01-23",1552,6,204),
 (1005,"2023-02-20",205,7,205),
 (1006,"2023-03-25",58,8,207),
 (1007,"2023-04-29",475,9,208),
 (1008,"2023-05-22",455,10,209),
 (1009,"2023-05-01",331,11,209),
 (1010,"2023-06-22",5,12,210),
 (1011,"2024-01-20",5,13,201),
 (1012,"2024-01-20",51,14,202),
(1013,"2024-01-20",3,15,203),
(1014,"2024-01-21",2,16,205),
(1015,"2024-02-02",25,17,204),
(1016,"2024-02-10",34,18,206),
(1017,"2024-02-02",24,19,207),
(1018,"2024-02-11",20,20,208),
(1019,"2024-02-12",5,19,210),
(1020,"2024-02-12",31,18,209),
(1021,"2024-02-13",43,17,208),
(1022,"2024-02-15",45,16,207),
(1023,"2024-02-21",13,15,206);
-- SELECT * FROM Sales;

--  l’elenco dei prodotti venduti e il fatturato totale per anno.

SELECT DISTINCT
    P.Product_Id,
    P.Product_Name,
    CAST(P.Price * SUM(S.Quantity_Sold) AS DECIMAL (10 , 2 )) Total,
    YEAR(S.Transaction_Date) Years
FROM
    Product P
        LEFT JOIN
    Sales S ON P.Product_Id = S.Product_Id
GROUP BY 1 , 4
ORDER BY 3 DESC;

--  il fatturato totale per stato e per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT 
    R.Region_Name,
    CAST(P.Price * SUM(S.Quantity_Sold) AS DECIMAL (10 , 2 )) Total,
    YEAR(S.Transaction_Date) Years
FROM
    Region R
        JOIN
    Sales S ON S.Region_Id = R.Region_Id
        JOIN
    Product P ON S.Product_Id = P.Product_Id
GROUP BY R.Region_Id , Years
ORDER BY 2 DESC, 3 DESC;

--  la categoria di articoli maggiormente richiesta dal mercato
SELECT 
    P.Category, SUM(S.Quantity_Sold) Qty_Sold
FROM
    Product P
        LEFT JOIN
    Sales S ON P.Product_Id = S.Product_Id
GROUP BY 1
ORDER BY 2 DESC
LIMIT 1;

--  i prodotti invenduti
SELECT 
    P.Product_Name
FROM
    Product P
        JOIN
    Sales S ON P.Product_Id = S.Product_Id
WHERE
    (SELECT 
            SUM(S.Quantity_Sold)
        FROM
            Sales S) = NULL;
            
            -- SOLUZIONE 2 I PRODOTTI INVENDUTI
            
            SELECT 
    P.Product_Id, P.Product_Name, SUM(S.Quantity_Sold) Qty_Sold
FROM
    Product P
        LEFT JOIN
    Sales S ON P.Product_Id = S.Product_Id
WHERE
    S.Quantity_Sold = 0
GROUP BY 1;

--  l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    P.Product_Name, S.Transaction_Date
FROM
    Product P
        LEFT JOIN
    Sales S ON P.Product_Id = S.Product_Id
ORDER BY 2 DESC;
